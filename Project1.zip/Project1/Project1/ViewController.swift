//
//  ViewController.swift
//  Project1
//
//  Created by ywubshit on 9/22/17.
//  Copyright © 2017 ywubshit. All rights reserved.
//

import UIKit
class ViewController: UIViewController {
    //outlet for the label displaying the number
    @IBOutlet weak var display: UILabel!
    //outlet for the button that decreases the number on the display label
    @IBOutlet weak var decerase: UIButton!
    //outlet for the button that increases the number on the display label
    @IBOutlet weak var increase: UIButton!
    //a variable that stores the "red" value as a double for the font color of the display label
    var redIndex = 0.5
    //a variable that stores the "green" value as a double for the font color of the displa label
    var greenIndex = 0.0005
    //a variable that stores the "blue" value as a double  for the font color of the display label
    var blueIndex = 0.0009
    //a variable that stores the "red" value as a double for the font color of the background color of the main view
    var redIndexBack = 0.97
    //a variable that stores the "green" value as a double for the font color of the background color of the main view
    var greenIndexBack = 0.0005
    //a variable that stores the "blue" value as a double for the font color of the background color of the main view
    var blueIndexBack = 0.0009
    
    //UIColor variable that stores the background color of the main view
    var colorBack:UIColor = UIColor(red: 0.02, green: 0.5569, blue: 0, alpha: 1.0){
        didSet{
            self.view.backgroundColor = UIColor(red: CGFloat(redIndexBack), green: CGFloat(greenIndexBack), blue: CGFloat(blueIndexBack), alpha: 1.0)          }
    }
    
    //UIColor variable that stores the background color of the display label
    var color:UIColor = UIColor(red: 0.02, green: 0.5569, blue: 0, alpha: 1.0) {
        didSet{
            display.textColor = UIColor(red: CGFloat(redIndex), green: CGFloat(greenIndex), blue: CGFloat(blueIndex), alpha: 1.0)        }
    }
    
    //a counter that counts the number to be displayed on the label (screen)
    var i:Double = 1 {
        didSet{
            display.text = String(format: "%.0f", i)
            
        }
    }
    //a variable that stores the font size of the number displayed on the label (screen)
    var fontSize: Double = 10{
        didSet{
            display.font = display.font.withSize(CGFloat(fontSize))        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // a Touch Up Inside Action Controller for the increasing button
    @IBAction func increaseNumber(_ sender: Any) {
        //increase the number on the label (screen) and its font size
        i+=1
        fontSize+=1.5
        //set the color of the number and the background color of the main view to be determined by the variables that store the respective red, greeen, and blue values
        color = UIColor(red: CGFloat(blueIndex), green: CGFloat(greenIndex), blue: CGFloat(blueIndex), alpha: 1.0)
        colorBack = UIColor(red: CGFloat(redIndexBack), green: CGFloat(greenIndexBack), blue: CGFloat(blueIndexBack), alpha: 1.0)
        
        //change the color values of the font color for the number displayed as the increaseNumber button is clicked
        blueIndex = blueIndex + 0.0105
        redIndex+=0.009
        greenIndex+=0.025
        //change the color values of the background color with respect to the font color of the number to create a contrasting color effect
        redIndexBack = 1 - redIndex
        greenIndexBack = 1 - greenIndex
        blueIndexBack = 1 - blueIndex
        
        //ensure that any color index will not go above 1
        if blueIndex>0.9{
            blueIndex = 0.001
        }
        if greenIndex>0.8{
            greenIndex = 0.2
        }
        if redIndex>0.8 {
            redIndex = 0.3
        }
        //set the maximum font size of the displayed number to 80.5
        if fontSize>80{
            fontSize = 3
        }
    }
    
    // a Touch Up Inside Action Controller for the increasing button
    @IBAction func decreaseNumber(_ sender: Any) {
        //increase the number on the label (screen) and its font size
        i-=1
        fontSize-=1.5
        if fontSize<3{
            fontSize = 80
        }
        //set the color of the number and the background color of the main view to be determined by the variables that store the respective red, greeen, and blue values
        color = UIColor(red: CGFloat(blueIndex), green: CGFloat(greenIndex), blue: CGFloat(blueIndex), alpha: 1.0)
        colorBack = UIColor(red: CGFloat(redIndexBack), green: CGFloat(greenIndexBack), blue: CGFloat(blueIndexBack), alpha: 1.0)
        
        //change the color values of the font color for the number displayed as the increaseNumber button is clicked
        blueIndex = blueIndex - 0.0105
        redIndex-=0.009
        greenIndex-=0.025
        //change the color values of the background color with respect to the font color of the number to create a contrasting color effect
        redIndexBack = 1 - redIndex
        greenIndexBack = 1 - greenIndex
        blueIndexBack = 1 - blueIndex
        
        //enusre that the color index will not fall below 0.1
        if blueIndex<0.1{
            blueIndex = 0.001
        }
        if greenIndex<0.1{
            greenIndex = 0.2
        }
        if redIndex<0.1 {
            redIndex = 0.3
        }
    }
}
