//
//  Photo.swift
//  Gallery
//
//  Created by ywubshit on 10/13/17.
//  Copyright © 2017 ywubshit. All rights reserved.
//

import Foundation

struct Photo {
    let id: String
    let owner: String
    let secret: String
    let server: String
    let farm: Int
    let title: String
    let isPublic: Int
    let isFriend: Int
    let isFamily: Int
    let url:URL
    let data: Data
    let urlString: String
    
    init(id: String, owner: String, secret: String, server: String, farm: Int,
         title: String, isPublic: Int, isFriend: Int, isFamily: Int, url: URL, data: Data, urlString: String){
        self.id = id
        self.owner = owner
        self.secret = secret
        self.server = server
        self.farm = farm
        self.title = title
        self.isPublic = isPublic
        self.isFriend = isFriend
        self.isFamily = isFamily
        self.url = url
        self.data = data
        self.urlString = "https://farm\(farm).staticflickr.com/"+server+"/"+id+"_"+secret+".jpg"
        
    }
    
    init(dictionary: [String: AnyObject]){
        let id = dictionary["id"] as! String
        let owner = dictionary["owner"] as! String
        let secret = dictionary["secret"] as! String
        let server = dictionary["server"] as! String
        let farm = dictionary["farm"] as! Int
        let title = dictionary["title"] as! String
        let isPublic = dictionary["ispublic"] as! Int
        let isFriend = dictionary["isfriend"] as! Int
        let isFamily = dictionary["isfamily"] as! Int
        let url = URL(string: "https://farm\(farm).staticflickr.com/"+server+"/"+id+"_"+secret+".jpg")
        let data = NSData(contentsOf: url!)! as Data
        let urlString = "https://farm\(farm).staticflickr.com/"+server+"/"+id+"_"+secret+".jpg"
        
        self.init(id: id, owner: owner, secret: secret, server:server, farm: farm,
                  title: title, isPublic: isPublic, isFriend: isFriend,
                  isFamily: isFamily, url: url!, data: data, urlString: urlString)
    }
   
}
