//
//  PhotoViewController.swift
//  Gallery
//
//  Created by ywubshit on 10/14/17.
//  Copyright © 2017 ywubshit. All rights reserved.
//

import UIKit

class PhotoViewController: UIViewController{
    
    var photo: Photo?
    
    @IBOutlet weak var id: UILabel!
    @IBOutlet weak var tit: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var family: UILabel!
    @IBOutlet weak var friend: UILabel!
    @IBOutlet weak var `public`: UILabel!
    
    // opens the original source link when the View Original Source button is pressed
    @IBAction func originalSource(_ sender: Any) {
        UIApplication.shared.openURL(NSURL(string: (photo?.urlString)!)! as URL)
    }
    
    @IBAction func close(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.image = UIImage(data: (photo?.data)!)
        tit.text = "Title: " + (photo?.title)!
        id.text = "ID: " + (photo?.id)!
        if(photo?.isFamily==1){
            family.backgroundColor = UIColor.green
        }
        else{
            family.backgroundColor = UIColor.red
        }
        
        if(photo?.isFriend==1){
            friend.backgroundColor = UIColor.green
        }
        else{
            friend.backgroundColor = UIColor.red
        }
        if(photo?.isPublic==1){
            `public`.backgroundColor = UIColor.green
        }
        else{
            `public`.backgroundColor = UIColor.red
        }
        
        // sets a random background color for the PhotoViewController view
        self.view.backgroundColor = UIColor(red: CGFloat(Float(arc4random()) / Float(UINT32_MAX)), green: CGFloat(Float(arc4random()) / Float(UINT32_MAX)), blue: CGFloat(Float(arc4random()) / Float(UINT32_MAX)), alpha: 1.0)
    }
}
