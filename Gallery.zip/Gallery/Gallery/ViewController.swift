//
//  ViewController.swift
//  Gallery
//
//  Created by ywubshit on 10/13/17.
//  Copyright © 2017 ywubshit. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    
    var photos: [Photo] = []

    @IBOutlet weak var progressBar: UIProgressView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.dataSource = self
        collectionView.delegate = self
        fetchData()
    }
    
    // fetches data from a JSON and stores the information to a dictionary of Photos
    func fetchData() {
        let url = URL(string: "https://api.flickr.com/services/rest/?format=json&sort=random&method=flickr.photos.search&tags=daffodil&tag_mode=all&api_key=0e2b6aaf8a6901c264acb91f151a3350&nojsoncallback=1")!
        let session = URLSession(configuration: .default)
        let task = session.dataTask(with: url) { (data, response, err) in
            let data = data!
            // a dictionary that stores information from the JSON
            let json = try! JSONSerialization.jsonObject(with: data, options: []) as! [String: AnyObject]
            let array = json["photos"]!["photo"] as! [[String: AnyObject]]
            self.photos = array.map { Photo(dictionary: $0) }
            print("\(self.photos)")
            DispatchQueue.main.async {
                self.collectionView.reloadData()
            }
            
        }
        task.resume()
    }
}

extension ViewController: UICollectionViewDataSource {
    // sets the size of the collection view to the number of Photos to be displayed
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BrowserCell", for: indexPath) as! BrowserCell
        cell.configure(photo: photos[indexPath.item])
        return cell
    }
}

extension ViewController: UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let photoViewController = storyBoard.instantiateViewController(withIdentifier: "PhotoViewController") as! PhotoViewController
        photoViewController.photo = photos[indexPath.item]
        present(photoViewController, animated: true, completion: nil)
    }
}

