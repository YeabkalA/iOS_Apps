import UIKit

class BrowserCell: UICollectionViewCell {
    
    var photo: Photo?
    
    override func prepareForReuse() {
        super.prepareForReuse()
       
    }
    
    func configure(photo: Photo) {
        self.photo = photo
        self.imageView.image = UIImage(data: photo.data)
    }
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var idLabel: UILabel!
    
    @IBOutlet weak var isFriend: UILabel!
    
   
    
    
}
